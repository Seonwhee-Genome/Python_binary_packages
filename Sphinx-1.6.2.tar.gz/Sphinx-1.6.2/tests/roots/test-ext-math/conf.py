# -*- coding: utf-8 -*-

master_doc = 'index'

latex_documents = [
    (master_doc, 'test.tex', 'Math Extension Testing', 'Sphinx', 'report')]
