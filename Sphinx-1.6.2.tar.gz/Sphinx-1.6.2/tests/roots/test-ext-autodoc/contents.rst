
.. automodule:: autodoc_dummy_module
   :members:
