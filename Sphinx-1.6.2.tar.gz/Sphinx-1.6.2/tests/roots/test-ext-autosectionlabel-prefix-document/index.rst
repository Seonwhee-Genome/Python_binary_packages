=========================================
test-ext-autosectionlabel-prefix-document
=========================================


Introduce of Sphinx
===================

Installation
============

For Windows users
-----------------

For UNIX users
--------------


References
==========

* :ref:`index:Introduce of Sphinx`
* :ref:`index:Installation`
* :ref:`index:For Windows users`
* :ref:`index:For UNIX users`
