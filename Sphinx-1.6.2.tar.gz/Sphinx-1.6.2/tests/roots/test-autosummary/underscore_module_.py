"""
module with trailing underscores everywhere
"""
class class_(object):
    """ Class """
    def method_(_arg):
        """ Method """
        pass

def function_(_arg):
    """ Function """
    pass
