# -*- coding: utf-8 -*-

extensions = ['sphinx.ext.intersphinx']
master_doc = 'index'
