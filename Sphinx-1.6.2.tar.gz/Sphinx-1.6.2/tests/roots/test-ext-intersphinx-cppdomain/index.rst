test-ext-intersphinx-cppdomain
==============================

.. cpp:namespace:: foo

:cpp:class:`Bar`
