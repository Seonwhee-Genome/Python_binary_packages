"""
####################
scripts
####################
Location of built-in scripts.
"""
