"""
####################
blacktie
####################
Main executable hook.
---------------------
This exposes script to analyze with the pipeline.
"""

__version__ = '0.2.1.2'


from blacktie.scripts.blacktie_pipeline import *


    

if __name__ == "__main__":
    
    main()