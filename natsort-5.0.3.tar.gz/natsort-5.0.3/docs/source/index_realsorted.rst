.. default-domain:: py
.. currentmodule:: natsort

:func:`~natsort.index_realsorted`
=================================

.. autofunction:: index_realsorted

