.. default-domain:: py
.. currentmodule:: natsort

:func:`~natsort.humansorted`
============================

.. autofunction:: humansorted

