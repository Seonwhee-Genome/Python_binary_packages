.. default-domain:: py
.. currentmodule:: natsort

:func:`~natsort.order_by_index`
===============================

.. autofunction:: order_by_index

