.. default-domain:: py
.. currentmodule:: natsort

:func:`~natsort.versorted`
==========================

.. autofunction:: versorted

