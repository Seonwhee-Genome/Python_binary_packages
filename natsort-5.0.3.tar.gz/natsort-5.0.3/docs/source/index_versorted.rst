.. default-domain:: py
.. currentmodule:: natsort

:func:`~natsort.index_versorted`
================================

.. autofunction:: index_versorted

